<?php
/**
 * Banner Section
 * 
 * @package Spa_and_Salon
 */

do_action( 'spa_and_salon_banner' ); 
